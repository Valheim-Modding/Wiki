﻿using Mono.Cecil.Cil;
using MonoMod.Cil;
using Steamworks;
using System;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

namespace ValheimPersonalisedTemplate
{
    public static class Hooks
    {
        internal static void Init()
        {
            //IL.*
            //On.*
        }

        
    }
}
